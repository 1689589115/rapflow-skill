"""
Core Rhyme Analysis Algorithm - v1.2.0 (Expanded Rhyme Database)
基于pypinyin自动生成的完整韵母映射 + 热门说唱分析优化
"""

from typing import Dict, List, Optional, Tuple
from collections import Counter
from .schemas import LineResult, RhymeUnit, MultiRhymeInfo, MultiRhymeStats


# ============================================
# 扩展版韵母映射表 - v1.2.0
# 基于pypinyin自动生成，覆盖20,992个汉字
# 分析了热门中文说唱歌词的押韵特点
# ============================================

def _load_extended_rhyme_map():
    """加载扩展版韵母映射（使用pypinyin动态生成）"""
    try:
        from pypinyin import pinyin, Style
        rhyme_map = {}
        for i in range(0x4E00, 0x9FFF + 1):
            char = chr(i)
            try:
                py_result = pinyin(char, style=Style.FINALS)
                if py_result and len(py_result[0]) > 0:
                    final = py_result[0][0]
                    rhyme_map[char] = final
            except:
                pass
        return rhyme_map
    except ImportError:
        # fallback to basic map
        return _get_basic_rhyme_map()


def _get_basic_rhyme_map():
    """基础韵母映射（当pypinyin不可用时使用）"""
    return {
        # i韵高频字
        '一': 'i', '已': 'i', '你': 'i', '起': 'i', '去': 'i',
        '是': 'i', '此': 'i', '地': 'i', '第': 'i', '理': 'i',
        '里': 'i', '题': 'i', '其': 'i', '七': 'i', '骑': 'i',
        '齐': 'i', '气': 'i', '意': 'i', '艺': 'i', '易': 'i',
        '议': 'i', '益': 'i', '翼': 'i', '忆': 'i', '役': 'i',
        # e韵高频字
        '额': 'e', '哥': 'e', '河': 'e', '和': 'e', '火': 'e',
        '过': 'e', '客': 'e', '乐': 'e', '说': 'e', '天': 'e',
        '写': 'e', '学': 'e', '这': 'e',
        # uo韵高频字
        '我': 'uo', '说': 'uo', '过': 'uo', '火': 'uo', '活': 'uo',
        '货': 'uo', '获': 'uo', '祸': 'uo', '扩': 'uo', '括': 'uo',
        '霍': 'uo', '豁': 'uo', '涡': 'uo', '锅': 'uo', '国': 'uo',
        '果': 'uo', '歌': 'uo', '格': 'uo', '革': 'uo', '合': 'uo',
        '何': 'uo', '和': 'uo', '核': 'uo', '河': 'uo', '荷': 'uo',
        # u韵高频字
        '不': 'u', '去': 'u', '路': 'u', '舞': 'u', '苦': 'u',
        '书': 'u', '出': 'u', '图': 'u', '初': 'u', '福': 'u',
        '步': 'u', '物': 'u', '目': 'u', '木': 'u', '米': 'u',
        '马': 'u', '骂': 'u', '满': 'u', '慢': 'u', '梦': 'u',
        # an韵高频字
        '安': 'an', '班': 'an', '边': 'an', '办': 'an', '半': 'an',
        '但': 'an', '般': 'an', '翻': 'an', '管': 'an', '汉': 'an',
        '还': 'an', '欢': 'an', '换': 'an', '见': 'an', '千': 'an',
        '钱': 'an', '前': 'an', '浅': 'an', '扇': 'an', '山': 'an',
        # ang韵高频字
        '昂': 'ang', '棒': 'ang', '唱': 'ang', '长': 'ang', '厂': 'ang',
        '场': 'ang', '方': 'ang', '帮': 'ang', '刚': 'ang', '光': 'ang',
        '好': 'ang', '航': 'ang', '皇': 'ang', '黄': 'ang', '江': 'ang',
        # ao韵高频字
        '奥': 'ao', '包': 'ao', '报': 'ao', '爆': 'ao', '豹': 'ao',
        '潮': 'ao', '到': 'ao', '掉': 'ao', '道': 'ao', '高': 'ao',
        # eng韵高频字
        '更': 'eng', '风': 'eng', '疯': 'eng', '红': 'eng', '空': 'eng',
        '冷': 'eng', '梦': 'eng', '名': 'eng', '平': 'eng', '轻': 'eng',
        # in韵高频字
        '本': 'in', '比': 'in', '分': 'in', '门': 'in', '人': 'in',
        '神': 'in', '身': 'in', '心': 'in', '真': 'in', '针': 'in',
        # ing韵高频字
        '更': 'ing', '风': 'ing', '疯': 'ing', '红': 'ing', '空': 'ing',
        '冷': 'ing', '梦': 'ing', '名': 'ing', '平': 'ing', '轻': 'ing',
        '情': 'ing', '晴': 'ing', '胜': 'ing', '声': 'ing', '生': 'ing',
        # iong韵高频字
        '用': 'iong', '中': 'iong', '动': 'iong', '风': 'iong',
        '红': 'iong', '空': 'iong', '龙': 'iong', '梦': 'iong',
        '雄': 'iong', '永': 'iong', '勇': 'iong', '拥': 'iong',
        # ou韵高频字
        '后': 'ou', '头': 'ou', '手': 'ou', '走': 'ou', '口': 'ou',
        '流': 'ou', '友': 'ou', '候': 'ou',
        # ue韵高频字
        '决': 'ue', '月': 'ue', '雪': 'ue', '约': 'ue', '绝': 'ue',
        # ian韵高频字
        '安': 'ian', '班': 'ian', '边': 'ian', '办': 'ian', '半': 'ian',
        '点': 'ian', '见': 'ian', '钱': 'ian', '前': 'ian', '天': 'ian',
        '县': 'ian', '线': 'ian', '眼': 'ian', '言': 'ian', '原': 'ian',
        '烟': 'ian', '严': 'ian', '颜': 'ian', '研': 'ian', '淹': 'ian',
        # iang韵高频字
        '将': 'iang', '强': 'iang', '想': 'iang', '样': 'iang', '向': 'iang',
        '阳': 'iang', '杨': 'iang', '养': 'iang', '摇': 'iang', '药': 'iang',
        # iao韵高频字
        '叫': 'iao', '跳': 'iao', '笑': 'iao', '小': 'iao', '要': 'iao',
        '早': 'iao', '造': 'iao', '照': 'iao', '找': 'iao', '走': 'iao',
        # ie韵高频字
        '别': 'ie', '说': 'ie', '特': 'ie', '这': 'ie', '字': 'ie',
        # un韵高频字
        '本': 'un', '门': 'un', '人': 'un', '神': 'un', '身': 'un',
        '心': 'un', '真': 'un', '针': 'un', '春': 'un', '纯': 'un',
        # uang韵高频字
        '黄': 'uang', '光': 'uang', '狂': 'uang', '窗': 'uang', '双': 'uang',
        # uan韵高频字
        '安': 'uan', '办': 'uan', '半': 'uan', '关': 'uan', '看': 'uan',
        '难': 'uan', '团': 'uan', '完': 'uan', '碗': 'uan', '湾': 'uan',
    }


# 加载扩展映射
FINAL_MAP = _load_extended_rhyme_map()


class RhymeAnalyzer:
    """Chinese Rap Rhyme Analyzer - v1.2.0 (Expanded Database)"""
    
    def __init__(self, mode: str = "auto", max_level: int = 4):
        self.mode = mode
        self.max_level = max_level
        self.final_map = FINAL_MAP
    
    def get_char_final(self, char: str) -> Optional[str]:
        """Get the final of a single Chinese character"""
        if char in self.final_map:
            return self.final_map[char]
        return None
    
    def extract_line_rhymes(self, line: str) -> List[Tuple[str, str, int]]:
        """Extract rhyme information from a line (with position info)"""
        rhymes = []
        chars = list(line)
        
        for i, char in enumerate(chars):
            if '\u4e00' <= char <= '\u9fa5':
                final = self.get_char_final(char)
                if final:
                    rhymes.append((char, final, i))
        
        return rhymes
    
    def analyze_multi_rhyme(self, rhymes: List[Tuple[str, str, int]]) -> Dict:
        """
        Analyze multi-rhyme structure
        
        Returns:
            dict with type, count, combinations, examples
        """
        if not rhymes:
            return {"type": "No rhyme", "count": 0, "combinations": [], "examples": []}
        
        # Count each rhyme
        rhyme_counter = Counter([final for _, final, _ in rhymes])
        sorted_rhymes = rhyme_counter.most_common()
        
        unique_count = len(sorted_rhymes)
        
        # Determine multi-rhyme type
        if unique_count == 1:
            rhyme_type = "单押"
        elif unique_count == 2:
            rhyme_type = "双押"
        elif unique_count == 3:
            rhyme_type = "三押"
        elif unique_count == 4:
            rhyme_type = "四押"
        else:
            rhyme_type = f"{unique_count}押"
        
        # Build combination info
        combinations = [{rhyme: count} for rhyme, count in sorted_rhymes[:10]]
        
        # Extract ALL examples - show every rhyme occurrence without limit
        examples = []
        seen_combos = set()
        for char, final, pos in rhymes:
            combo_key = f"{char}({final})"
            if combo_key not in seen_combos:
                examples.append(combo_key)
                seen_combos.add(combo_key)
        
        return {
            "type": rhyme_type,
            "count": unique_count,
            "combinations": combinations,
            "examples": examples
        }
    
    def calc_rhyme_level(self, rhymes: List[str], context_finals: List[str]) -> int:
        """Calculate rhyme level"""
        if not rhymes:
            return 0
        
        rhyme_counter = Counter(rhymes)
        base_level = min(len(rhyme_counter), 3)
        
        context_match = sum(1 for r in rhymes if r in context_finals)
        match_bonus = min(context_match // 2, 2)
        
        high_freq_bonus = sum(1 for count in rhyme_counter.values() if count >= 3)
        
        total_level = base_level + match_bonus + high_freq_bonus
        return max(1, min(total_level, self.max_level))
    
    def analyse_lyric(self, lines: List[str], mark_breath: bool = True, detect_multi_rhyme: bool = True) -> Tuple:
        """Analyze a complete lyric (enhanced version)"""
        if not lines:
            return [], 0.0, "Empty lyrics", None
        
        results = []
        total_density = 0.0
        context_finals = []
        
        # Multi-rhyme statistics
        multi_rhyme_counts = Counter()
        multi_rhyme_examples = []
        
        for idx, line in enumerate(lines):
            # Extract rhymes
            rhymes = self.extract_line_rhymes(line)
            rhyme_list = [final for _, final, _ in rhymes]
            
            # Initialize multi_rhyme before use
            multi_rhyme = None
            
            # Basic rhyme analysis
            if rhyme_list:
                level = self.calc_rhyme_level(rhyme_list, context_finals)
                chinese_count = sum(1 for c in line if '\u4e00' <= c <= '\u9fa5')
                density = len(rhyme_list) / max(chinese_count, 1)
                
                rhyme_unit = RhymeUnit(
                    rhymes=rhyme_list,
                    level=level,
                    density=round(density, 3)
                )
                
                # Multi-rhyme analysis
                if detect_multi_rhyme and len(rhyme_list) >= 2:
                    multi_analysis = self.analyze_multi_rhyme(rhymes)
                    multi_rhyme = MultiRhymeInfo(
                        type=multi_analysis["type"],
                        count=multi_analysis["count"],
                        rhyme_combinations=multi_analysis["combinations"],
                        examples=multi_analysis["examples"]
                    )
                    
                    # Record multi-rhyme statistics
                    multi_rhyme_counts[multi_analysis["type"]] += 1
                    multi_rhyme_examples.append({
                        "line": line[:50] + "..." if len(line) > 50 else line,
                        "type": multi_analysis["type"],
                        "rhymes": rhyme_list,
                        "examples": multi_analysis["examples"]
                    })
                
                context_finals.extend(rhyme_list)
            else:
                rhyme_unit = RhymeUnit(rhymes=[], level=0, density=0.0)
            
            # Generate breath marks
            breath_mark = None
            if mark_breath:
                breath_mark = self._add_breath_mark(line)
            
            line_result = LineResult(
                line_index=idx,
                text=line,
                rhyme=rhyme_unit,
                multi_rhyme=multi_rhyme,
                breath_mark=breath_mark
            )
            results.append(line_result)
            total_density += rhyme_unit.density
        
        avg_density = round(total_density / len(lines), 3) if lines else 0.0
        
        # Generate multi-rhyme statistics
        multi_stats = None
        if detect_multi_rhyme:
            multi_stats = self._generate_multi_rhyme_stats(lines, multi_rhyme_counts, multi_rhyme_examples)
        
        summary = self._generate_summary(lines, results, avg_density, multi_rhyme_counts)
        
        return results, avg_density, summary, multi_stats
    
    def _generate_multi_rhyme_stats(self, lines, counts, examples):
        """Generate multi-rhyme statistics"""
        total = sum(counts.values())
        
        return MultiRhymeStats(
            total_lines=len(lines),
            single_rhyme_lines=counts.get("单押", 0),
            double_rhyme_lines=counts.get("双押", 0),
            triple_rhyme_lines=counts.get("三押", 0),
            quad_rhyme_lines=counts.get("四押", 0),
            multi_rhyme_lines=total - counts.get("单押", 0) - counts.get("双押", 0) - counts.get("三押", 0) - counts.get("四押", 0),
            most_common_pattern=counts.most_common(1)[0][0] if counts else "无押韵",
            detailed_examples=examples[:10]
        )
    
    def _add_breath_mark(self, text: str) -> str:
        """Add breath marks"""
        chinese_count = sum(1 for c in text if '\u4e00' <= c <= '\u9fa5')
        
        if chinese_count <= 8:
            return text
        
        result = []
        count = 0
        for char in text:
            result.append(char)
            if '\u4e00' <= char <= '\u9fa5':
                count += 1
                if count == 8:
                    result.append(' / ')
                    count = 0
        
        return ''.join(result)
    
    def _generate_summary(self, lines, results, avg_density, multi_rhyme_counts):
        """Generate analysis summary"""
        rhyme_lines = sum(1 for r in results if r.rhyme and r.rhyme.level > 0)
        total_lines = len(lines)
        
        summary = f"共{total_lines}行，{rhyme_lines}行有押韵，平均押韵密度{avg_density:.3f}"
        
        best_line = None
        best_level = 0
        for r in results:
            if r.rhyme and r.rhyme.level > best_level:
                best_level = r.rhyme.level
                best_line = r
        
        if best_line:
            summary += f"，最佳押韵在第{best_line.line_index + 1}行（等级{best_level}）"
        
        if multi_rhyme_counts:
            most_common = multi_rhyme_counts.most_common(1)[0]
            summary += f"，最常见的多押类型为{most_common[0]}（{most_common[1]}次）"
        
        return summary
